"""
TrendRadar MCP Server

提供基于MCP协议的新闻聚合数据查询和系统管理接口。
"""

__version__ = "1.0.0"
